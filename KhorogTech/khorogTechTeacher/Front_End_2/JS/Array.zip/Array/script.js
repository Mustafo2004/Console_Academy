//! Task-1
//??Создайте пустой массив numbers.
// ?Добавьте в этот массив числа от 1 до 5, используя только метод push.
// ?Удалите из массива первый элемент с помощью метода shift.
// ?Добавьте в массив число 6, используя метод push.
// ?Удалите из массива последний элемент с помощью метода pop.
// ?Выведите получившийся массив в консоль.
// let numbers = [];
// numbers.push(1);
// numbers.push(2);
// numbers.push(3);
// numbers.push(4);
// numbers.push(5);

// numbers.shift();

// numbers.push(6);

// numbers.pop();

// console.log(numbers);

// ! Task-2
// ?Создайте массив fruits с элементами "яблоко", "апельсин" и "банан".
// ?Удалите из массива первый элемент с помощью метода shift.
// ?Добавьте в массив "киви" с помощью метода push.
// ?Удалите из массива последний элемент с помощью метода pop.
// ?Выведите получившийся массив в консоль.

// let fruits = ["яблоко", "апельсин", "банан"];
// fruits.shift();
// fruits.push("киви");
// fruits.pop();
// console.log(fruits);

// !Task-3
//? Создайте пустой массив names.
//? Добавьте в этот массив своё имя с помощью метода push.
//? Удалите из массива ваше имя с помощью метода shift.
//? Выведите получившийся массив в консоль.
// let names = [];
// names.push("Ваше имя");
// names.shift();
// console.log(names);

// !Task-4

//? Создайте массив numbers и добавьте число 10 в начало массива, используя метод unshift. Затем выведите массив в консоль.
// let numbers = [20, 30, 40];
// numbers.unshift(10);
// console.log(numbers);
// ! Task-5
//? Удалите последний элемент из массива fruits и выведите его в консоль. Массив fruits и вывод должны выглядеть следующим образом:
// let fruits = ["яблоко", "банан", "апельсин"];
// let removedFruit = fruits.pop();
// console.log("Удаленный фрукт: " + removedFruit);
// console.log(fruits);
// ! Task-6
// ?Создайте массив letters и добавьте в него букву Z в конец, используя метод push. Затем выведите массив в консоль.
// let letters = ['A', 'B', 'C'];
// letters.push('Z');
// console.log(letters);
// ! Task-7
//? Удалите первый элемент из массива colors и выведите его в консоль. Массив colors и вывод должны выглядеть следующим образом:
// let colors = ["красный", "зеленый", "синий"];
// let removedColor = colors.shift();
// console.log("Удаленный цвет: " + removedColor);
// console.log(colors);
// ! Task-8
// ?Создайте массив animals и измените в нем второй элемент на слон, используя обращение к элементу по индексу. Затем выведите массив в консоль.
// let animals = ['кот', 'собака', 'хомяк'];
// animals[1] = 'слон';
// console.log(animals);

// ! Task-9
//? Создайте массив letters с элементами "a", "b", "c", "d". Удалите первый элемент массива и выведите его на экран. Затем добавьте в конец массива элементы "x", "y", "z" с помощью метода push.
// * Ожидаемый результат: ["b", "c", "d", "x", "y", "z"]
// let letters = ["a", "b", "c", "d"];
// let removedLetter = letters.shift();
// letters.push("x", "y", "z");
// console.log(removedLetter); 
// console.log(letters); 

// ! Task-10
// ?Создайте массив colors с элементами "красный" и "зеленый". Добавьте в начало массива "синий" с помощью метода unshift. Затем удалите последний элемент массива и выведите его на экран.
//* Ожидаемый результат: "зеленый"
// let colors = ["красный", "зеленый"];
// colors.unshift("синий");
// let removedColor = colors.pop();
// console.log(removedColor); 


let student1 = "Mustafo"
let student2 = "Mustafos    qd"
let student3 = "Mustafewfwefewfweo"


let people = ["Mustafo"]

// get element based on index
// push
// pop
// 

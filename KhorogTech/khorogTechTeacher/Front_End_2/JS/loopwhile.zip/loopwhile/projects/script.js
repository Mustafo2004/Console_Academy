const imageNewPizza = [
    {
      image: "./images/pizza.png",
      name: "Карбонара",
      price: "от 120 ₽",
    },
    {
      image: "./images/pizza.png",
      name: "Карбонара",
      price: "от 120 ₽",
    },
    {
      image: "./images/pizza.png",
      name: "Карбонара",
      price: "от 120 ₽",
    },
    {
      image: "./images/pizza.png",
      name: "Карбонара",
      price: "от 120 ₽",
    },
  ];
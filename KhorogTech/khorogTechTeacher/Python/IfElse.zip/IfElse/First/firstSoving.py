# Задача 1
x = 15
if x > 10:
    print("Больше 10")
else:
    print("Меньше или равно 10")

# Задача 2
s = "привет"
if s == "привет":
    print("Привет!")
else:
    print("Не привет!")

# Задача 3
a = 7
if a % 2 == 0:
    print("Четное число")
else:
    print("Нечетное число")

# Задача 4
b = 9
if b % 3 == 0:
    print("Делится на 3")
else:
    print("Не делится на 3")

# Задача 5
is_raining = False
if is_raining:
    print("Идет дождь")
else:
    print("Сегодня сухо")

# Задача 6
is_sunny = True
if is_sunny:
    print("Солнечно")
else:
    print("Облачно")

# Задача 7
is_weekend = True
if is_weekend:
    print("Ура, выходные!")
else:
    print("Рабочая неделя")

# Задача 8
has_pet = False
if has_pet:
    print("У вас есть питомец")
else:
    print("Питомца нет")

# Задача 9
is_cold = True
if is_cold:
    print("Холодно")
else:
    print("Тепло")

# Задача 10
is_night = False
if is_night:
    print("Ночь")
else:
    print("День")

# Задача 11
is_holiday = False
if is_holiday:
    print("Праздник")
else:
    print("Рабочий день")

# Задача 12
is_light_on = True
if is_light_on:
    print("Свет включен")
else:
    print("Свет выключен")

# Задача 13
is_playing = False
if is_playing:
    print("Играем")
else:
    print("Отдыхаем")

# Задача 14
is_birthday = True
if is_birthday:
    print("День рождения")
else:
    print("Не день рождения")

# Задача 15
is_spring = False
if is_spring:
    print("Весна")
else:
    print("Не весна")

# Задача 16
is_school_day = False
if is_school_day:
    print("Школа")
else:
    print("Каникулы")

# Задача 17
is_evening = True
if is_evening:
    print("Вечер")
else:
    print("День")

# Задача 18
is_winter = True
if is_winter:
    print("Зима")
else:
    print("Не зима")

# Задача 19
has_cake = False
if has_cake:
    print("Есть торт")
else:
    print("Нет торта")

# Задача 20
is_happy = True
if is_happy:
    print("Счастлив")
else:
    print("Не счастлив")

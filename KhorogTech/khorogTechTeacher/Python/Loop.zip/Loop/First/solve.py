# Task 1: Напечатать числа от 1 до 5.
for i in range(1, 6):
    print(i)

print() 

# Task 2: Напечатать числа от 10 до 15.
for i in range(10, 16):
    print(i)

print() 

# Task 3: Напечатать строку 'Привет' пять раз.
for i in range(5):
    print('Привет')

print() 

# Task 4: Напечатать числа от 0 до 4.
for i in range(5):
    print(i)

print() 

# Task 5: Напечатать строку 'Python' три раза.
for i in range(3):
    print('Python')

print() 

# Task 6: Напечатать числа от 1 до 10.
for i in range(1, 11):
    print(i)

print() 

# Task 7: Напечатать строки 'Учусь программировать' четыре раза.
for i in range(4):
    print('Учусь программировать')

print() 

# Task 8: Напечатать числа от 5 до 9.
for i in range(5, 10):
    print(i)

print() 

# Task 9: Напечатать строку 'Кодинг это весело' два раза.
for i in range(2):
    print('Кодинг это весело')

print() 

# Task 10: Напечатать числа от 3 до 7.
for i in range(3, 8):
    print(i)

print() 

# Task 11: Напечатать строку 'Циклы в Python' три раза.
for i in range(3):
    print('Циклы в Python')

print() 

# Task 12: Напечатать числа от 2 до 6.
for i in range(2, 7):
    print(i)

print() 

# Task 13: Напечатать строку 'Программирование' четыре раза.
for i in range(4):
    print('Программирование')

print() 

# Task 14: Напечатать числа от 4 до 8.
for i in range(4, 9):
    print(i)

print() 

# Task 15: Напечатать строку 'Изучаю Python' два раза.
for i in range(2):
    print('Изучаю Python')

print() 

# Task 16: Напечатать числа от 6 до 10.
for i in range(6, 11):
    print(i)

print() 

# Task 17: Напечатать строку 'Понимаю циклы' три раза.
for i in range(3):
    print('Понимаю циклы')

print() 

# Task 18: Напечатать числа от 1 до 3.
for i in range(1, 4):
    print(i)

print() 

# Task 19: Напечатать строку 'Начало пути' четыре раза.
for i in range(4):
    print('Начало пути')

print() 

# Task 20: Напечатать числа от 8 до 12.
for i in range(8, 13):
    print(i)

import random

def get_word():
    # List of words to guess
    words = ["python", "javascript", "hangman", "programming", "challenge"]
    return random.choice(words)

def display_word(word, guessed_letters):
    # Create a string with underscores for letters that have not been guessed
    result = ""
    for letter in word:
        if letter in guessed_letters:
            result += letter
        else:
            result += "_"
    return result

def guess_the_word():
    word = get_word()
    guessed_letters = set()  # Set to keep track of guessed letters
    attempts = 6  # Number of attempts
    guessed_word = display_word(word, guessed_letters)

    print("Welcome to 'Guess the Word'!")
    print("Try to guess the word.")

    while attempts > 0:
        print(f"Word: {guessed_word}")
        print(f"Attempts left: {attempts}")
        guess = input("Guess a letter: ").lower()

        if len(guess) != 1 or not guess.isalpha():
            print("Please enter a single letter.")
            continue

        if guess in guessed_letters:
            print("You've already guessed that letter.")
            continue

        guessed_letters.add(guess)

        if guess in word:
            print("Good guess!")
        else:
            print("Incorrect guess.")
            attempts -= 1

        guessed_word = display_word(word, guessed_letters)

        if "_" not in guessed_word:
            print(f"Congratulations! You've guessed the word: {word}")
            break
    else:
        print(f"Sorry, you're out of attempts. The word was: {word}")

# Start the game
guess_the_word()
